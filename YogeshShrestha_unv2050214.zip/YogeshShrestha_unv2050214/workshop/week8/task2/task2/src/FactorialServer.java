import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class FactorialServer {
    public static void main(String[] args) {
        try {
            System.out.println("Waiting for Clients....");
            ServerSocket ss = new ServerSocket(9806);
            Socket soc = ss.accept(); //establishes connection   
            System.out.println("Connection Established");
            
            BufferedReader userInput = new BufferedReader(new InputStreamReader(System.in));
            int number = Integer.parseInt(userInput.readLine());
            PrintWriter out = new PrintWriter(soc.getOutputStream(), true);
            out.println("Factorial of"+number+"is:"+calculateFactorial(number));
        }
        
        catch (Exception e){
            e.printStackTrace();
        }
        
    }
    
    static int calculateFactorial(int number)  //passing number parameter in function
    {
        int fact = 1;
        for (int i = 0 ; i<= number; i++)
        {
            fact = fact * 1;
        }
        
        return fact;
    }
}
